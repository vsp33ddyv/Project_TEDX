// functies voor iframe
function gaNaar(file) {
	document.getElementById("kader").src = file;
}


		public function view_list(){
	
        $data['title'] = "Home";
        $data['frames'] = array(
            "Welcome/events"$doc->Load('book.xml');
            ,"Welcome/forum"
            ,"Welcome/about"
            ,"Welcome/contact"
        );


		public function view_list(){
		$data['title'] = "Home";
		$doc = new DomDocument;
		$doc->Load('homepage.php');
		$this->load->view($doc->getElementById('kader'),$data);
    }