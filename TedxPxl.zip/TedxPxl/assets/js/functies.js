function overlay(){
	er = document.getElementById("achtergrond");
	el = document.getElementById("login");
	el.style.visibility = (el.style.visibility == "visible") ? "hidden"
	: "visible";
	
	
}
<<<<<<< .mine
/* functie voor iframe: maar wordt effe ni meer gebruikt*/
function gaNaar(file) {
	document.getElementById("kader").src = file;
}
=======




>>>>>>> .r68
