<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Homepage extends CI_Controller {
	public function index(){
		$this->home();
		$this->load->database();		
	}
	
	public function home(){
		$this->load->view("header");
		$this->load->view("homepage");
		$this->load->view("footer");
        $this->load->view("mycal");
		$this->load->database();
	}

		public function view_list(){
        $data['title'] = "Home";
        $data['frames'] = array(
            "Welcome/events"
            ,"Welcome/forum"
            ,"Welcome/about"
            ,"Welcome/contact"
        );
		echo 'Hello';
		$this->load->view("Homepage", $data);
		}

		 public function events(){ 		
        $this->load->view("events_view");
		}

		
		public function displayCal(){
		$this->load->model('Mycal_model');
		
			if($this->input->post('day')){
			$this->Mycal_model->add_calendar_data(
				
			);
			}	
		
		$data['calendar'] = $this->Mycal_model->generate();
		
		$this->load->view('mycal',$data);
			
		}
		}