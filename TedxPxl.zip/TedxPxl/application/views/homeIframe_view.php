﻿<?php
defined('BASEPATH') OR exit('NO direct script access allowed');
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Home</title>
</head>
<body>
</body>
</html>