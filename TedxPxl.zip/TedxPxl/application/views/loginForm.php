<!DOCTYPE html>
<html>
	<head>
		<title>TedPxl</title>
		<meta charset="UTF-8" />
		<link href="<?= base_url();?>assets/css/login.css" rel="stylesheet" type="text/css" />
		<!-- css werkt -->
		<script></script>
	</head>
	<body>
		<img id="logo" src="public/img/logoPopup.png" alt="logo"/>
		<hr>
		<div id="allOfit">
			<div id="links">
				<h1>Wordt nu lid en geniet van de vele voordelen</h1>
				<ul>
					<li>It's totally free</li>
					<li>Get free comments</li>
					<li>Give free comments</li>
					<li>Get an own name</li>
					<li>Show yourself free</li>
					<li>It's better than twilight</li>
					<li>Maybe you get free pizza</li>
					<li>Get the latest updates</li>
					<li>Enjoy our parties</li>
				</ul>
				<input class="signup" type="button" value="Sign up NOW"/>
			</div>
			
			<div id="rechts">
				<h1>Ben jij al een geweldig lid</h1>
				<input class="signup" type="button" value="Sign in"/>
			</div>
		</div>
	</body>
</html>