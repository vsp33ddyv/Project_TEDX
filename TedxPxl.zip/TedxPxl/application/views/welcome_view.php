<?php
defined('BASEPATH') OR exit('NO direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome</title>
</head>
<body>
<!---
	<?php 
	foreach ($frames as $frame):?>
            <iframe src="<?php echo $frame?>"></iframe>
        <?php endforeach;?>
		--->
	<h1>Welcome</h1>
	<pre>Controller = Welcome.php</pre>
	<pre>View = Welcome_view.php</pre>
</body>
</html>