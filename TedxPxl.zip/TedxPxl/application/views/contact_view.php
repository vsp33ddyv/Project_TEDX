﻿<?php
defined('BASEPATH') OR exit('NO direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Contact</title>       
    </head>
    <body>
        <h1>Contact</h1>
    </body>
</html>